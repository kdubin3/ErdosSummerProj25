CTA Expenditures

A set of files from the Data Transparency Portal listing CTA's expenditures by year. Data is available from 2015 through the current year.

An updated version of the most recent file is sent to the RTA by CTA staff on a monthly basis. 

VENDOR NAME: The name of the expenditure's vendor
EXPENSE CATEGORY: A brief description of the expenditure
PAYMENT AMOUNT: The monetary value of the expenditure
PAYMENT DATE: The date of the expenditure